#include "video_filter.h"
#ifndef __linux__
int video_filter_CfgInitialize(video_filter *InstancePtr, video_filter_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->video_filter_BaseAddress = ConfigPtr->video_filter_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void video_filter_gateway_in_write(video_filter *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    video_filter_WriteReg(InstancePtr->video_filter_BaseAddress, 0, Data);
}
u32 video_filter_gateway_in_read(video_filter *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = video_filter_ReadReg(InstancePtr->video_filter_BaseAddress, 0);
    return Data;
}
