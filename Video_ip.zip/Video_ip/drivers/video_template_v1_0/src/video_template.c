#include "video_template.h"
#ifndef __linux__
int video_template_CfgInitialize(video_template *InstancePtr, video_template_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->video_template_BaseAddress = ConfigPtr->video_template_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void video_template_gateway_in_write(video_template *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    video_template_WriteReg(InstancePtr->video_template_BaseAddress, 0, Data);
}
u32 video_template_gateway_in_read(video_template *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = video_template_ReadReg(InstancePtr->video_template_BaseAddress, 0);
    return Data;
}
