/**
* @file video_template_sinit.c
*
* The implementation of the video_template driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "video_template.h"
extern video_template_Config video_template_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type video_template_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
video_template_Config *video_template_LookupConfig(u16 DeviceId) {
    video_template_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_VIDEO_TEMPLATE_NUM_INSTANCES; Index++) {
        if (video_template_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &video_template_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int video_template_Initialize(video_template *InstancePtr, u16 DeviceId) {
    video_template_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = video_template_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return video_template_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
